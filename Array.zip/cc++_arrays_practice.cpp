#include <iostream>
#include <stdio.h>
/*just in case the code makes error with iostream*/

using namespace std;

int main()
{
    int A[5];
    /*in real, integer takes 4 bytes*/
    A[0] = 12;
    A[1] = 15;
    A[2] = 25;

    cout << sizeof(A) << endl;
    /*count size of A > size of array is 20*/
    /*endl is for new line so after printing 20, cursor will move to the next line and 15 will be printed*/
    cout << A[1] << endl;
    printf("%d\n", A[2]);
    /*print A of 2*/
    /*cout is for C++, prinf is for C*/
    return 0;
}
